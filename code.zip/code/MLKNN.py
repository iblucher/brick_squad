
# coding: utf-8

# In[1]:


# Import packages and set working directory
import glob
import os
import json
import numpy as np
from sklearn.metrics import f1_score
from sklearn.metrics import hamming_loss
from PIL import Image
from read_label import *
from skmultilearn.adapt import MLkNN


# In[2]:


#Sort images by numerical order

def sortKeyFunc(s):
    return int(os.path.basename(s)[:-4])


# In[3]:


# Turn dictionary keys to integer values

def get_key(key):
    try:
        return int(key)
    except ValueError:
        return key


# In[4]:


# Resize and flatten images

def imageprep(path):
    # get list of files
    filelist = glob.glob(path)
    filelist.sort(key=sortKeyFunc)
    n_samples = len(filelist)
    print(filelist[:10])
    print(n_samples)
    return;

    # resize images
    images_resized = [Image.open(fname).resize((64,64), Image.ANTIALIAS) for fname in filelist]
    # print(images_resized)

    # convert images to numpy array
    x_multidim = np.array([np.array(image) for image in images_resized])
    #print(x_multidim.shape)

    # flatten the numpy array
    return x_multidim.reshape(n_samples, -1)
    # print(x.shape)
    # print(x)


# In[5]:


# Read labels from json and transform into binary matrix

def multi_label(path):
    dic = {}
    ids = []
    binary_labels = []
    with open(path, 'r') as f:
        data = json.load(f)
    max_value = 0
    for i in data["annotations"]:
        for j in range(len(i["labelId"])):
            if max_value < int(i["labelId"][j]):
                max_value = int(i["labelId"][j])
    print(max_value)
    for i in data["annotations"]:
        tmp = [0]*max_value
        for j in i["labelId"]:
            tmp[int(j)-1] = 1
        dic[i["imageId"]] = tmp
    for key, labels in sorted(dic.items(), key = lambda t: get_key(t[0])):
        # print(key)
        # print(labels)
        ids.append(key)
        binary_labels.append(labels)
    ids = np.array(ids)
    binary_labels = np.array(binary_labels)
    # print(ids.shape)
    # print(binary_labels.shape)

    return ids, binary_labels


# In[6]:


def submission_format(ids, labels):
    # transform final predictions into correct submission format
    ids = np.array(ids)
    labels = np.array(labels)

    [r, c] = labels.shape
    with open('submission.csv', 'wb') as f:
        f.write("image_id, label_id")
        f.write('\n')
        for i in range(r):
            lab = []
            for l in range(c):
                if labels[i, l] == 1:
                    lab.append(l + 1)
            l = ' '.join(str(v) for v in lab)
            data = '{},{}'.format(ids[i], l)
            f.write(data)
            f.write('\n')


# In[7]:


# Prepare feature matrix and label matrix

Xtrain = imageprep('train_images/*.jpg')
# Xval  = imageprep('val_images/*.jpg')

# i, ytrain = multi_label("train.json")
# i, yval = multi_label("validation.json")


# In[ ]:


# Fit classifier and predict output labels

classifier = MLkNN(k=10)

classifier.fit(Xtrain, ytrain)

predictions = classifier.predict(Xval)


# In[ ]:


# Compute F1 score

acc = f1_score(yval, predictions, average="micro")
print("F1 Score: {}".format(acc))


# In[ ]:


# Compute Hamming loss

ham = hamming_loss(yval, predictions)
print("Hamming loss: {}".format(ham))


# In[ ]:


with open("result.txt", "w") as f:
    f.write("F1 Score: {}\n".format(acc))
    f.write("Hamming loss: {}\n".format(ham))

