from os import listdir
from os.path import isfile, join, basename, abspath
from PIL import Image
import numpy as np

def fileName(s):
    return int(basename(s)[:-4])

path = "train_images/"
fnpy = "arrays/train_arrays.npy"
size = 32

images = sorted([f for f in listdir(path) if isfile(join(path, f)) and f.endswith(".jpg")], key=fileName)
resized = [Image.open(join(path, fname)).resize((size,size), Image.ANTIALIAS) for fname in images]
arr = np.array([np.array(image) for image in resized])
flat = arr.reshape(len(images), -1)
np.save(fnpy, flat)
